
#!/bin/bash
CUDA_VISIBLE_DEVICES=0,1 python /home/user9/USenhance23_POAS-main/train.py --dataroot /home/user9/us_train --testdataroot /home/user9/us_test --name test --n_epochs 300 --checkpoints_dir /home/user9/checkpoint --gpu_ids 1 --input_nc 1 --output_nc 1 --batch_size 4 --phase train --is_mtl --dataset_mode unaligned2 --lr 0.0001